﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day22
{
    class Employee
    {
        public int id;
        public string name;
        public float sal;
        public string dept;

        public Employee()
        {
            id = 0;
            name = "";
            sal = 100;
            dept = "";
        }

        public void getdata()
        {
            Console.Write("ID  = ");
            id = Convert.ToInt32(Console.ReadLine());
            Console.Write("NAME  = ");
            name = Console.ReadLine();
            Console.Write("SALARY  = ");
            sal = float.Parse(Console.ReadLine());
            Console.Write("DEPT  = ");
            dept = Console.ReadLine();
        }
        public void display()
        {
            Console.WriteLine(" ID      " + id);
            Console.WriteLine(" NAME    " + name);
            Console.WriteLine(" SAL     " + sal);
            Console.WriteLine(" DEPT    " + dept);
        }
    }
}
