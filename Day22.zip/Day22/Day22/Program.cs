﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day22
{
    class Program
    {
        static void Main(string[] args)
        {

            int n;
            float maxsal=0;
            float sum=0;
            Console.WriteLine("Enter num of records = ");
            n = int.Parse(Console.ReadLine());

            Employee[] emp = new Employee[n];

            for (int i=0;i<n;i++)
            {
                emp[i] = new Employee();
                emp[i].getdata();
                sum += emp[i].sal;
                if (emp[i].sal > maxsal)
                    maxsal = emp[i].sal;
            }
            Console.WriteLine("\nthe records enteres = \n");
            for (int i = 0; i < n; i++)
                 emp[i].display();

            Console.WriteLine("SUM of all the salries of employees = "+ sum);

            string dep;
            Console.WriteLine("Enter the department name ");
            dep = Console.ReadLine();

            int count = 0,flag=0;
            for (int i = 0; i < n; i++)
            {
                if(dep == emp[i].dept)
                {
                    count++;
                    Console.WriteLine("\n________RECORD {0} ___________", count);
                    emp[i].display();
                    flag = 1;
                }
            }
            if(flag==0)
                Console.WriteLine("DEPT {0} doesnt exit",dep);
            else
                Console.WriteLine("TOTAL MATCHING RECORDS = "+count);

            Console.WriteLine("\n the employees with max salary ");

            for(int i=0;i<n;i++)
            {
                
                if (emp[i].sal == maxsal)
                {
                    Console.WriteLine("RECORD  : ");
                    emp[i].display();
                }
                    
            }


        }
    }
}
