﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day22
{
    class Program2
    {
        static void Main(string[] args)
        {
            Shape ob = new Shape();
            ob.display();

            Shape ob1 = new Shape(7,8);
            ob1.display();

            Shape ob2 = new Shape(3,4,99);
            ob2.display();
            
        }
    }
}
