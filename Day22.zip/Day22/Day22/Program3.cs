﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day22
{
    class Program3
    {
        static void Main(string[] args)
        {
            Rectangle ob = new Rectangle(22, 3);
            ob.display();
        }
    }
}
