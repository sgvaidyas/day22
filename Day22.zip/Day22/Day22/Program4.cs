﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day22
{
    class Point
    {
        private int x, y;
        internal void get(int x,int y)
        {
            this.x = x;
            this.y = y;
        }
        internal void display()
        {
            Console.WriteLine("POINT = {0} and {1}",x,y);
        }
    }

    class Program4
    {
        static void Main(string[] args)
        {
            Point ob = new Point();
            ob.get(33, 4);
            ob.display();
        }
    }
}
