﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day22
{
    class Point1
    {
        public int x, y;
        public Point1()
        {
            x = 0;
            y = 0;
        }
        public Point1(int x,int y)
        {
            this.x = x;
            this.y = y;
        }
        public void getdata()
        {
            Console.WriteLine("Enter x and y val");
            x = int.Parse(Console.ReadLine());
            y = int.Parse(Console.ReadLine());
        }
        public void display()
        {
            Console.WriteLine("POINT X={0} & Y={1}",x,y);
        }
        public static Point1 operator+(Point1 a, Point1 b)
        {
            Point1 res=new Point1();
            res.x = a.x + b.x;
            res.y = a.y + b.y;

            return res;
        }
        public Point1 minus(Point1 ob)
        {
            Point1 res = new Point1();
            res.x = this.x - ob.x;
            res.y = this.y - ob.y;
            return res;
        }
    }
    class Program5
    {
        static void Main(string[] args)
        {
            Point1 ob1 = new Point1(3,5);
            Point1 ob2 = new Point1(9, 1);

            Point1 ob3 = ob1+ob2;
            ob1.display();
            ob2.display();
            ob3.display();
            Point1 ob4 = ob1.minus(ob2);
            ob4.display();
        }
    }
}
