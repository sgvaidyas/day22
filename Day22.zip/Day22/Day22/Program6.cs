﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day22
{
    class Program6
    {
        static void Main(string[] args)
        {
            int n;
            Point1 sum = new Point1();
            Console.WriteLine("Enter the no of points");
            n = int.Parse(Console.ReadLine());

            Point1[] p = new Point1[n];

            for(int i=0;i<n;i++)
            {
                p[i] = new Point1();
                p[i].getdata();
                sum = sum + p[i];
            }
            sum.display();
        }
    }
}
