﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day22
{
    class Myclass
    {
        string name;
        public static int count=0;
        public Myclass()
        {
            Console.WriteLine("Enter the name");
            name = Console.ReadLine();
            count++;
        }
        public void display()
        {
            Console.WriteLine("\nNAME = {0}\t COUNT={1}",name,count);
        }
    }
    class Program7
    {
        static void Main(string[] args)
        {
            Myclass ob1 = new Myclass();
            ob1.display();
            Myclass ob2 = new Myclass();
            ob2.display();
            ob1.display();
            ob2.display();
            Myclass.count = 88;
            ob1.display();
            ob2.display();
        }
    }
}
