﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day22
{
    class Rectangle
    {
        public float len, bred,area,peri;

        public Rectangle(int len,int bred)
        {
            this.len = len;
            this.bred = bred;
            area = len * bred;
            peri = 2 * (len + bred);
        }
        public void display()
        {
            Console.WriteLine("LENGTH      = " + len);
            Console.WriteLine("BREADTH     = " + bred);
            Console.WriteLine("AREA        = " + area);
            Console.WriteLine("PERIMETER   = " + peri);
        }

    }
}
