﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day22
{
    class Shape
    {
        public float len;
        public float bred;
        public float rad;

        //default 
        public Shape()
        {
            Console.WriteLine("Enter length breadth & radius");
            len = float.Parse(Console.ReadLine());
            bred = float.Parse(Console.ReadLine());
            rad = float.Parse(Console.ReadLine());
        }
        //constructor 1 parameter
        public Shape(float x)
        {
            len = x;
            bred = x;
            rad = x;
        }
        public Shape(float x,float y, float z=3)
        {
            len = x;
            bred = y;
            rad = z;
        }
        string Shapestring()
        {
            string str = " ";
            str = len + " " + bred + " " + rad;
            return str;
        }

        ~Shape()
        {
            Console.WriteLine("The object is destructed" + Shapestring());
        }
        public void display()
        {
            Console.WriteLine("\nLENGTH   = " + len);
            Console.WriteLine("BREADTH  = " + bred);
            Console.WriteLine("RADIUS   = " + rad);
        }
    }
}
